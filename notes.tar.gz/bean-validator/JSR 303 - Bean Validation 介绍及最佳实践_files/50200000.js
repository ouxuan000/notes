coremetrics.cmUpdateConfig({"at":true,"io":true,"ia":true,"ddx":{"version":3}}); coremetrics.cmLoad();
