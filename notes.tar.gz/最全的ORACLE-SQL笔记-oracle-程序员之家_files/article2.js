//document.write('<script type="text/javascript">/*300*250，创建于2013-1-24*/var cpro_id = "u1200386";</script>');
//document.write('<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>');
