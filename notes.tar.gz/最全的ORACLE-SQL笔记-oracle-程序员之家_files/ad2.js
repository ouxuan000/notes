﻿//document.write('<script type="text/javascript">/*960*90，创建于2013-1-24*/ var cpro_id = "u1200410";</script>');
//document.write('<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>')
//document.write('<a href="http://js.50bang.org/?formType=7337" target="_blank"><img src="/templets/default/images/2345.gif"></a>')