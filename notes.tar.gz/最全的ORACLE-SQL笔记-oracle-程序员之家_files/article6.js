document.write('<script type="text/javascript">var cpro_id = "u1350274";</script>');
document.write('<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>');