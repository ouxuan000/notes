//document.write('<script type="text/javascript"> /* 创建于 2014-12-03*/ var cpro_id = "u1200962";</script>');
//document.write('<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>');
document.write('<script>var qj_uid="703019";var qj_t=0;</script>')
document.write('<script charset="utf-8" src="http://vip.yule8.net/js/cpm.js"></script>')
document.write('<script>var qj_uid="703019";var qj_maxw=0;</script>')
document.write('<script charset="utf-8" src="http://vip.yule8.net/js/cpv_fm_r.js"></script>')